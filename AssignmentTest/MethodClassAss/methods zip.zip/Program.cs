﻿using System;
namespace MethodClass;
class Program{
    
    public static void Main(string[] args)
    {
        
    }
}
